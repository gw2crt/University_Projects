#!/bin/bash

######################################
# Filename - CPU5003 UNIX Assignment #
# Gareth Weston - GW2CRT             #
######################################

#A script to list all the files in the root directory

echo "Listing all the files in the Root Directory"
echo
cd /
ls
echo
echo "Heading back to the Main Menu"
echo
sleep 10

cd /
./home/gw2crt/ass_folder/main_menu
echo

## END OF SCRIPT
