var timerID = 0;
var clockRunning = new Boolean;
clockRunning = false;

function startClock(){
    
    if (!clockRunning){
        clockRunning = true;
        timerID = setInterval('displayTime()', 1000);       
    }else {
        alert("The Clock is already running");
    } 
}

function stopClock(){
    
    clearInterval(timerID);
    clockRunning = false;
}

function displayTime(){
    
    var now = new Date();
    var day = now.getDate();
    var month = now.getMonth();
    var year = now.getYear();    
    var hours = now.getHours();
    var minutes = now.getMinutes();
    var seconds = now.getSeconds();
    
    var timeString = hours > 12 ? hours -12 : hours;
    timeString += minutes < 10 ? ":0" : ":";
    timeString += minutes;
    timeString += seconds < 10 ? ":0" : ":";
    timeString += seconds;
    timeString += hours > 12 ? " PM" : " AM";
    timeString += day;
    timeString += month;
    timeString += year;
    
    document.digitalClock.display.value = timeString;
}











    