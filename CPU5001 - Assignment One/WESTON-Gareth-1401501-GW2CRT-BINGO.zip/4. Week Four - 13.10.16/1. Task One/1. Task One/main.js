function displayTime(){
    
    var now = new Date();
    document.digitalClock.display.value = now.toLocaleString();

}











    