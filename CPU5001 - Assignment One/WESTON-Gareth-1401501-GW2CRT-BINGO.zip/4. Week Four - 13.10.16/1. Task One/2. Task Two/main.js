var timerID = 0;

function startClock(){
   alert("hello from start");
    timerID = setInterval('displayTime()', 1000);  
    
}

function stopClock(){
    alert("hello from stop");
    clearInterval(timerID);
}

function displayTime(){
    
    var now = new Date();
    var hours = now.getHours();
    var minutes = now.getMinutes();
    var seconds = now.getSeconds();
    
    var timeString = hours;
    timeString += ":";
    timeString += minutes;
    timeString += ":";
    timeString += seconds;
    timeString += hours > 12 ? " PM" : " AM";
    
    document.digitalClock.display.value = timeString;

}











    