var timerID = 0;
var clockRunning = new Boolean;
clockRunning = false;

function startClock(){
    
    if (!clockRunning){
        clockRunning = true;
        timerID = setInterval('displayTime()', 1000);       
    }else {
        alert("The Clock is already running");
    } 
}

function stopClock(){
    
    clearInterval(timerID);
    clockRunning = false;
}

function displayTime(){
    
    var now = new Date();   
    var hours = now.getHours();
    var minutes = now.getMinutes();
    var seconds = now.getSeconds();
    
    var dateNum = now.getDate();
    var dayNum = now.getDay();
    var mthNum = now.getMonth();
    var year = now.getFullYear();
    
    var dayName = conversionDay(dayNum);
    var mthName = conversionMonth(mthNum);
    
    
    
    var timeString = hours > 12 ? hours -12 : hours;
    timeString += minutes < 10 ? ":0" : ":";
    timeString += minutes;
    timeString += seconds < 10 ? ":0" : ":";
    timeString += seconds;
    timeString += hours > 12 ? " PM" : " AM";
    timeString += "  ";
    timeString += dayName;
    timeString += " ";
    timeString += dateNum;
    timeString += " ";
    timeString += mthName;
    timeString += " ";
    timeString += year;
    
    document.digitalClock.display.value = timeString;
}

function conversionDay(dn){    
    var dayNames = new Array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
    
    return dayNames[dn];
}

function conversionMonth(mn){    
    var monthNames = new Array("Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec");
    
    return monthNames[mn];
}













    