function init(){  
    
}

function conversion(){
    
    var dayNames = new Array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
    
    var monthNames = new Array("January", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec");
    
    var now = new Date();
    var dateNum = now.getDate();
    var dayNum = now.getDay();
    var dayName = dayNames[dayNum];
    var mthNum = now.getMonth();
    var monthName = monthNames[mthNum];
        
    document.write("Today is " + dayName + " " + dateNum + "th " + monthName);
    
}
