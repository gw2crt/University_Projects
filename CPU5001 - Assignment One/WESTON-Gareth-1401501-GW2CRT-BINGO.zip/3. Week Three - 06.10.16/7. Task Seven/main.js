window.onload=init;

function init(){
    
    var now = new Date();
    var orderPlaced = new Date(2016,09,12);
    
    var orderPlacedMs = orderPlaced.getTime();
    var todayMsec = now.getTime();
    var tzOffset = now.getTimezoneOffset();
    
    var t1 = conversionOne(orderPlacedMs, todayMsec);
    //var t2 = conversionTwo(now, epochMsec, tzOffset);
    
    
    document.getElementById("display").innerHTML = t1;
   // document.getElementById("display1").innerHTML = t2;
    //document.getElementById("display2").innerHTML = x;
    //document.getElementById("display3").innerHTML = epochMsec;
    
}
//-------------------------------------------------------------
function conversionOne(orderPsec, todayMsec){
    
        return (todayMsec - orderPsec) / 86400000;
}

function conversionTwo(nw,epoch){
        
    return (nw -epoch) / 86400000;
}


//-------------------------------------------------------------

