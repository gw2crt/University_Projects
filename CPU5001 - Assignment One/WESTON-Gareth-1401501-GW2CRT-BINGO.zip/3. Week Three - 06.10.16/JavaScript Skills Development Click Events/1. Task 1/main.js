window.onload=init();

function init(){
    alert("loaded");
    
}

function DtoR(){
    
    var angleDeg = document.degConversion.degA.value;
    var angleRad = 0;
    
    angleRad = angleDeg * (Math.PI / 180);
    
    document.degConversion.rad.value=angleRad;

     
}

//-------------------------------------------------------------



//-------------------------------------------------------------

