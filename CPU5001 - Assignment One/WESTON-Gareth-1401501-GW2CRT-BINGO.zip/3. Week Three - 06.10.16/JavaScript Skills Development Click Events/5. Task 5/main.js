
function createCircle() {
    
    myCanvas = document.getElementById("myCanvas");
    ctx = myCanvas.getContext("2d");
    
    alert("loaded");
    
    rad = document.circle.radius.value;
    circleX = document.circle.xCoord.value;
    circleY = document.circle.yCoord.value;
    colour = "red";
    alert(rad);
    
    if (isNaN(rad) || isNaN(circleY) || isNaN(circleX)) {
        alert("Please enter the correct nemerical value.");
    }
    
    if (circleX < rad || circleX > (myCanvas.width - rad) || circleY < rad || circleY > (myCanvas.height - rad)) {
        alert("The values entered will create a circle outside of the canvas boundry please try again.");
    } else {
        
        drawCircle();        
    }      
}

//-------------------------------------------------------------
function drawCircle(){
    ctx.beginPath();
    ctx.arc(circleX,circleY,rad,0,2*Math.PI);
    ctx.fillStyle = colour;
    ctx.fill();
    ctx.lineWidth = 1;
    ctx.strokeStyle = 'black';
    ctx.stroke();
    
}

function increaseCircle(){
    
    rad ++;
    drawCircle()
        
}

function decreaseCircle(){
    
    rad --;
    clearCanvas()
    drawCircle()
}

function clearCanvas(){
    
    myCanvas = document.getElementById("myCanvas");
    ctx.clearRect(0, 0, myCanvas.width, myCanvas.height);
}


//-------------------------------------------------------------

