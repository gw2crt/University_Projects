window.onload = startUp;

function startUp() {
    
    randomNumber();
        
}

function circleMatrix() {
    
   myCanvas  = document.getElementById("myCanvas");
   ctx = myCanvas.getContext("2d");

    // Set up the initial values to be used for drawing a circle
        colour = 'yellow';
        circleX =  60;  // The x coord of the centre of the circle
        circleY = 50;  // The y coord of the centre of the circle
        rad =  35;   // The radius of the centre of the circle in pixel
      var gapBetweenCircles = 10;   // The gap between the circles //gives a 20px gap between each circle
      var circleOffsetX = 2*rad + gapBetweenCircles;
      var circleOffsetY = 2*rad + gapBetweenCircles;
        // The horizontal offset between circle centres this performs a calculation saving the result to the var.
    number = [];
    counter = 1;
      // Invoke a user-defined function to draw a circle a number of times
        //for loop designed to draw the circles starting at 1 increasing by one each time the loop is run.

        for (var j = 1; j <= 10; j++){
            for(var i = 1; i <= 10; i++){                  
            drawCircle(); 
            circleX += circleOffsetX;
            number.push(counter);
            counter++;
            }
            circleY += circleOffsetY;
            circleX = 60;            
        }
    document.getElementById("test").innerHTML = number.toString();
}

//-------------------------------------------------------------
function drawCircle(){
    ctx.beginPath();
    ctx.arc(circleX,circleY,rad,0,2*Math.PI);
    
    if (ranNum == counter){
    ctx.fillStyle = "green";
    } else {
        ctx.fillStyle = colour;
    }
    ctx.fill();
    ctx.lineWidth = 1;
    ctx.strokeStyle = 'black';
    ctx.stroke(); 
    
    ctx.font = "16px helvetica";
    ctx.fillStyle = "black";
    ctx.fillText(counter, circleX -10, circleY);
}

function clearCanvas(){
    
   var  myCanvas = document.getElementById("myCanvas");
    var ctx = myCanvas.getContext("2d")
    ctx.clearRect(0, 0, myCanvas.width, myCanvas.height);
}


function randomNumber(){
    
    randomNum = [];
    ranNum = 0;

        while (randomNum.length < 100){

            ranNum = (Math.floor(Math.random() * 100 +1));
            var found = false;
            
            for(var i=0; i < randomNum.length; i++){
                
                if(randomNum[i]==ranNum){
                    found = true; break}
                }
                if(!found)randomNum[randomNum.length] = ranNum;
                }
    
    document.getElementById("testNumber").innerHTML = ranNum;
    
    circleMatrix();    
}
    
//-------------------------------------------------------------

