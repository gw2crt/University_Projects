
function createCircle() {
    
    var myCanvas = document.getElementById("myCanvas");
    var ctx = myCanvas.getContext("2d");
    
    alert("loaded");
    
    rad = document.circle.radius.value;
    var circleX = document.circle.xCoord.value;
    var circleY = document.circle.yCoord.value;
    var colour = "red";
    
    if (isNaN(rad) || isNaN(circleY) || isNaN(circleX)) {
        alert("Please enter the correct nemerical value.");
    }
    
    if (circleX < rad || circleX > (myCanvas.width - rad) || circleY < rad || circleY > (myCanvas.height - rad)) {
        alert("The values entered will create a circle outside of the canvas boundry please try again.");
    } else {
        
        drawCircle(ctx,circleX,circleY,rad,colour);        
    }      
}

//-------------------------------------------------------------
function drawCircle(ctx,x,y,r,colour){
    ctx.beginPath();
    ctx.arc(x,y,r,0,2*Math.PI);
    ctx.fillStyle = colour;
    ctx.fill();
    ctx.lineWidth = 2;
    ctx.strokeStyle = 'black';
    ctx.stroke();
    
}


//-------------------------------------------------------------

