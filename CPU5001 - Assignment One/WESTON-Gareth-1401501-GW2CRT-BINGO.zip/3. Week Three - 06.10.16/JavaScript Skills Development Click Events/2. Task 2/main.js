

function init(){

        
}

function createCircle(){
    
    var myCanvas = document.getElementById("myCanvas");
    var ctx = myCanvas.getContext("2d");
    
    alert("loaded");
    
    var rad = document.circle.radius.value;
    var circleX = document.circle.xCoord.value;
    var circleY = document.circle.yCoord.value;
    var colour = "red";
   
    
    drawCircle(ctx,circleX,circleY,rad,colour);    
            
}

//-------------------------------------------------------------
function drawCircle(ctx,x,y,r,colour){
    ctx.beginPath();
    ctx.arc(x,y,r,0,2*Math.PI);
    ctx.fillStyle = colour;
    ctx.fill();
    ctx.lineWidth = 2;
    ctx.strokeStyle = 'black';
    ctx.stroke();
    
}


//-------------------------------------------------------------

