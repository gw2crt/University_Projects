function init(){
    
    var now = new Date();
    
    var year_num = now.getFullYear();
    var month_num = now.getMonth();
    var date_num = now.getDate();
    var day_num = now.getDay();
    var hour_num = now.getHours();
    var min_num = now.getMinutes();
    var sec_num = now.getSeconds();
    var mili_num = now.getMilliseconds();
    
    document.write("Year =" + year_num + "<br>");
    document.write("Month = " + month_num + "<br>");
    document.write("Date = " + date_num + "<br>");
    document.write("Day = " + day_num + "<br>");
    document.write("Hour = " + hour_num + "<br>");
    document.write("Min = "+ min_num + "<br>");
    document.write("Second = " + sec_num + "<br>");
    document.write("Milisecond = " + mili_num + "<br");

}

function date_Demo(){
    var now = new Date();
    
    document.write("Demo One" + " - " + "<br>");
    document.write("Year =" + now.getFullYear() + "<br>");
    document.write("Month =" + now.getMonth() + "<br>");
    document.write("Date =" + now.getDate() + "<br>");
    document.write("Day =" + now.getDay() + "<br>");
    document.write("Hours =" + now.getHours() + "<br>");
    document.write("Minutes =" + now.getMinutes() + "<br>");
    document.write("Seconds =" + now.getSeconds() + "<br>");
    document.write("Miliseconds =" + now.getMilliseconds() + "<br>");
    document.write("<br>");
}

function date_Demo2(){
    
    var testDate1 = new Date("December 19, 2016");
    
    document.write("Demo Two" + " - ");
    document.write(testDate1);
    document.write("<br>");
}

function date_Demo3(){
    
    var testDate2 = new Date(2016, 11, 19);
    
    document.write("Demo Three" + " - ");
    document.write(testDate2);
    document.write("<br>");
}

function date_Demo4(){
    
    var testDate3 = new Date(2017, 00, 09, 9, 00);
    
    document.write("Demo Four" + " - ");
    document.write(testDate3);
    document.write("<br>");
}














    