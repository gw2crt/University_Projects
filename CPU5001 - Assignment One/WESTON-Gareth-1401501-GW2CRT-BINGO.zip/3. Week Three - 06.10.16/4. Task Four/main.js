function init(){
    
    var dayNames = new Array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
    
    var now = new Date();
    var dayNum = now.getDay();
    var dayName = dayNames[dayNum];
    
    
    
  document.write("Todays Day Number is " + dayNum + " which is " + dayName);

}











    