window.onload=init;

function init(){
    
    var myCanvas = document.getElementById('myCanvas');
    var ctx = myCanvas.getContext('2d');
        
    var r = 0;
    var colour = 'red';
    r = prompt('Please enter the Circle Radius' , '50');

    var randX = Math.floor(Math.random() * myCanvas.width -80); 
    var randY = Math.floor(Math.random() * myCanvas.height -80);
    
    
    var x = randX - r;
    var y = randY - r;
    
    if ((x < myCanvas.width) && (y < myCanvas.height)){
    
    drawCircle(ctx , x , y , r , colour);
    } else {
        alert('Circle is outside the permitted area');
    }
}
        

//-------------------------------------------------------------

function drawCircle(ctx,x,y,r,col) {
    
    ctx.beginPath();
    ctx.arc(x,y,r,0,2*Math.PI);
    ctx.fillStyle = col;
    ctx.fill();
    ctx.lineWidth = 2;
    ctx.strokeStyle = 'black';
    ctx.stroke();
}

//-------------------------------------------------------------

