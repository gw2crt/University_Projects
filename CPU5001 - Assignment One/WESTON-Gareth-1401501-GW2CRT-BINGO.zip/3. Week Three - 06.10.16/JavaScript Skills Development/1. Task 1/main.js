window.onload=init;

function init(){
    
    var angleDeg = 0;
    var angleRad = 0;
    
    angleDeg = prompt('Please enter the Degrees' , '0 - 360');       
    angleRad = angleDeg * (Math.PI / 180);
        
    alert("The angle Degree" + angleDeg + "is " + angleRad.toFixed(2) + " Radians");
}

//-------------------------------------------------------------



//-------------------------------------------------------------

