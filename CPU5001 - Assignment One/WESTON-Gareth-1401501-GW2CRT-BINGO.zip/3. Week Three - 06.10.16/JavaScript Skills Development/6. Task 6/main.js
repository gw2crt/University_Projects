window.onload=init;

function init(){

      // Set up the drawing context object

      var myCanvas  = document.getElementById("myCanvas");
      var myContext = myCanvas.getContext("2d");

      // Set up the initial values to be used for drawing a circle
      var colour = 'red';
      var circleCentreX     = 60;  // The x coord of the centre of the circle
      var circleCentreY     = 100;  // The y coord of the centre of the circle
      var circleRadius      = 50;   // The radius of the centre of the circle in pixels
      //var numberOfCircles   = 1;    // The number of circles to be drawn
      var gapBetweenCircles = 10;   // The gap between the circles //gives a 20px gap between each circle
      var circleOffsetX     = 2*circleRadius + gapBetweenCircles;
      var circleOffsetY     = 2*circleRadius + gapBetweenCircles;
        // The horizontal offset between circle centres this performs a calculation saving the result to the var.

      // Invoke a user-defined function to draw a circle a number of times
        //for loop designed to draw the circles starting at 1 increasing by one each time the loop is run.

        for (var j = 1; j <= 4; j++){
            for(var i = 1; i <= 5; i++){                  
            drawCircle(myContext , circleCentreX , circleCentreY , circleRadius, colour);    
            circleCentreX += circleOffsetX; 
            }
            circleCentreY += circleOffsetY;
            circleCentreX = 60;            
        }
}
//-------------------------------------------------------------

function drawCircle(ctx,x,y,r,col) {
    
    ctx.beginPath();
    ctx.arc(x,y,r,0,2*Math.PI);
    ctx.fillStyle = col;
    ctx.fill();
    ctx.lineWidth = 2;
    ctx.strokeStyle = 'black';
    ctx.stroke();
}

//-------------------------------------------------------------

