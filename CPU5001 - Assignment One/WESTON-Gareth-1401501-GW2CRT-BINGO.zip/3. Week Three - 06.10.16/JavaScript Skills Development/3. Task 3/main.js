window.onload=init;

function init(){
    
    var myCanvas = document.getElementById('myCanvas');
    var ctx = myCanvas.getContext('2d');
    
    var x = 0;
    var y = 0;
    var r = 0;
    var colour = 'red';
    
    r = prompt('Please enter the Circle Radius' , '50');
    x = prompt('Please enter the X axis Position', '100');
    y = prompt('please enter the Y axis Position', '200');
             
    drawCircle(ctx , x , y , r , colour); //Dont forget to pass the variables to the function.
}

//-------------------------------------------------------------

function drawCircle(ctx,x,y,r,col) {
    
    ctx.beginPath();
    ctx.arc(x,y,r,0,2*Math.PI);
    ctx.fillStyle = col;
    ctx.fill();
    ctx.lineWidth = 2;
    ctx.strokeStyle = 'black';
    ctx.stroke();
}

//-------------------------------------------------------------

