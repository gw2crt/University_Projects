window.onload=init;

function init(){
alert("hello from init");
	
    var now = new Date();
    var dateNum = now.getDate();
    var dayNum = now.getDay();
    var mthNum = now.getMonth();
    
    var dayName = conversionDay(dayNum);
    var mthName = conversionMonth(mthNum);
    

	document.getElementById("display").innerHTML = dateNum + dayName + mthName;
}

//-------------------------------------------------------------
function conversionDay(dn){    
alert("hello from day converter");
    var dayNames = new Array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
    
    return dayNames[dn];
}
//-------------------------------------------------------------
function conversionMonth(mn){    
alert("hello from month converter");
    var monthNames = new Array("Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec");
    
    return monthNames[mn];
}



//-------------------------------------------------------------

