function init(){
    
    var now = new Date();
    
    var year_num = now.getFullYear();
    var month_num = now.getMonth();
    var date_num = now.getDate();
    var day_num = now.getDay();
    var hour_num = now.getHours();
    var min_num = now.getMinutes();
    var sec_num = now.getSeconds();
    var mili_num = now.getMilliseconds();
    var epochMsecs = now.getTime();
    var tzOffset = now.getTimezoneOffset();
    
    document.write("Year =" + year_num + "<br>");
    document.write("Month = " + month_num + "<br>");
    document.write("Date = " + date_num + "<br>");
    document.write("Day = " + day_num + "<br>");
    document.write("Hour = " + hour_num + "<br>");
    document.write("Min = "+ min_num + "<br>");
    document.write("Second = " + sec_num + "<br>");
    document.write("Milisecond = " + mili_num + "<br");
    document.write("Epoch" + epochMsecs + "<br>");
    document.write("Time Offset" + tzOffset + "<br");

}











    