window.onload = init;

function init(){

      // Set up the drawing context object

      var myCanvas  = document.getElementById("myCanvas");
      var ctx = myCanvas.getContext("2d");

      // Set up the initial values to be used for drawing a circle

      var circleCentreX     = 100;  // The x coord of the centre of the circle
      var circleCentreY     = 200;  // The y coord of the centre of the circle
      var circleRadius      = 50;   // The radius of the centre of the circle in pixels
      var numberOfCircles   = 6;    // The number of circles to be drawn
      var gapBetweenCircles = 20;   // The gap between the circles //gives a 20px gap between each circle
      var circleOffsetX     = 2*circleRadius + gapBetweenCircles;  // The horizontal offset between circle centres this performs  a calculation saving the result to the var.
      var colour = ['white', 'blue', 'purple', 'green', 'yellow', 'violet'];
      var x = null;
        //generates a random whole number between 1 and 59
      // Invoke a user-defined function to draw a circle a number of times
        //for loop designed to draw the circles starting at 1 increasing by one each time the loop is run.
        ctx.font = '40pt Helvetica';
        ctx.fillStyle = 'black';
        ctx.fillText("Tonights Lottery Numbers", 100, 70);
        
      for (var i = 1; i <= numberOfCircles; i++) {
          // Draw a circle
          var ranNum = Math.floor(Math.random() * 59 +1);
          
          if (ranNum <=10) {
              x = 0;
            drawCircle(ctx , circleCentreX , circleCentreY , circleRadius , ranNum , colour[x]);
            circleCentreX += circleOffsetX;
            } else if (ranNum > 10 && ranNum < 20) {
                x = 1;
                drawCircle(ctx , circleCentreX , circleCentreY , circleRadius , ranNum , colour[x]);
                circleCentreX += circleOffsetX;
            } else if (ranNum > 19 && ranNum < 30) {
                x = 2;
                drawCircle(ctx , circleCentreX , circleCentreY , circleRadius , ranNum , colour[x]);
                circleCentreX += circleOffsetX;
            } else if (ranNum > 29 && ranNum < 40) {
                x = 3;
                drawCircle(ctx , circleCentreX , circleCentreY , circleRadius , ranNum , colour[x]);
                circleCentreX += circleOffsetX;
            } else if (ranNum > 39 && ranNum < 50) {
                x = 4;
                drawCircle(ctx , circleCentreX , circleCentreY , circleRadius , ranNum , colour[x]);
                circleCentreX += circleOffsetX;
            } else if (ranNum > 49 && ranNum < 60) {
                x = 5;
                drawCircle(ctx , circleCentreX , circleCentreY , circleRadius , ranNum , colour[x]);
                circleCentreX += circleOffsetX;
            }         
           // Increment the x coordinate ready for the next circle
           // The adds the offset to the current x coord. 
      }

    }// User-defined function to draw a circle.  Note how it has
    // local variable to 'catch' the information being passed to it.

    function welcomeMsg(ctx,x,y){
        ctx.font = '40pt Helvetica';
        ctx.fillStyle = 'black';
        ctx.fillText("Tonights Lottery Numbers", 00, 10);
    }

    function drawCircle(ctx,x,y,r,ranNum,colour) {
        ctx.beginPath();
        ctx.arc(x,y,r,0,2*Math.PI);
        ctx.fillStyle = colour;
        ctx.fill();
        ctx.lineWidth = 2;
        ctx.strokeStyle = 'black';
        ctx.stroke();
        
        ctx.font = '30pt Helvetica';
        ctx.fillStyle = 'black';
        ctx.fillText(ranNum, x-20, y+15);
    }
    
    