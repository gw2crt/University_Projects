window.onload = init; //initilisation of the javascript 

//====================================================================

//function call
function init(){

	// Set up the drawing context object

	var myCanvas  = document.getElementById("myCanvas");
	var myContext = myCanvas.getContext("2d");

	// Set up the initial values to be used for drawing a circle

	var circleCentreX     = 400;  // The x coord of the centre of the circle
	var circleCentreY     = 200;  // The y coord of the centre of the circle
	var circleRadius      = 25;   // The radius of the centre of the circle in pixels
	var numberOfCircles   = 3;    // The number of circles to be drawn
	var gapBetweenCircles = 20;   // The gap between the circles
	var circleOffsetX     = 2*circleRadius + gapBetweenCircles;  // The horizontal offset between circle centres
	var circleColours     = ['Red', 'Green', 'Blue'];            // An array of strings representing the colours

	// Invoke a user-defined function to draw a circle a number of times
	// Notice how the loop counter starts from zero as that helps when dealing with arrays due to the array index
	// starting from zero.

	for (var i = 0; i < numberOfCircles ; i++) {
	  // Draw a circle        
	  drawCircle(myContext , circleCentreX , circleCentreY , circleRadius, circleColours[i]);
	  
	  // Increment the x coordinate ready for the next circle
	  circleCentreX += circleOffsetX; // The adds the offset to the current x coord.

	}

}  // End of init() function

//=======================================================================

// User-defined function to draw a circle.  Note how it has 
// local variable to 'catch' the information being passed to it.

function drawCircle(ctx,x,y,r,colour) {

	ctx.beginPath();
	ctx.arc(x,y,r,0,2*Math.PI);
	ctx.fillStyle = colour;
	ctx.fill();
	ctx.stroke();

}  // End of drawCircle() function


//========================================================================
