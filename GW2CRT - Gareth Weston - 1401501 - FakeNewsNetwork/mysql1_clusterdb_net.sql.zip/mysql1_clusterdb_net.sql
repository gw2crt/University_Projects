-- phpMyAdmin SQL Dump
-- version 4.4.9
-- http://www.phpmyadmin.net
--
-- Host: mysql1.clusterdb.net
-- Generation Time: Apr 25, 2017 at 02:17 PM
-- Server version: 10.0.28-MariaDB
-- PHP Version: 5.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gw2cr-mfh-u-094012`
--

-- --------------------------------------------------------

--
-- Table structure for table `fakenews`
--

CREATE TABLE IF NOT EXISTS `fakenews` (
  `id` smallint(5) NOT NULL,
  `image` text NOT NULL,
  `headline` text NOT NULL,
  `story` text NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fakenews`
--

INSERT INTO `fakenews` (`id`, `image`, `headline`, `story`, `name`, `email`, `timestamp`) VALUES
(1, './media/img_1.jpg', 'Donald Trump In Russian lady boy affair', 'We are going to make placeholder text great again. Greater than ever before. The other thing with Lorem Ipsum is that you have to take out its family.\r\n\r\nI was going to say something extremely rough to Lorem Ipsum, to its family, and I said to myself, "I can''t do it. I just can''t do it. It''s inappropriate. It''s not nice." All of the words in Lorem Ipsum have flirted with me - consciously or unconsciously. That''s to be expected. I was going to say something extremely rough to Lorem Ipsum, to its family, and I said to myself, "I can''t do it. I just can''t do it. It''s inappropriate. It''s not nice."\r\n\r\nLorem Ipsum is the single greatest threat. We are not - we are not keeping up with other websites. All of the words in Lorem Ipsum have flirted with me - consciously or unconsciously. That''s to be expected. If Trump Ipsum weren’t my own words, perhaps I’d be dating it.\r\n\r\nLorem Ipsum''s father was with Lee Harvey Oswald prior to Oswald''s being, you know, shot. This placeholder text is gonna be HUGE.\r\n\r\nAn ‘extremely credible source’ has called my office and told me that Barack Obama’s placeholder text is a fraud. Look at these words. Are they small words? And he referred to my words - if they''re small, something else must be small. I guarantee you there''s no problem, I guarantee. We are going to make placeholder text great again. Greater than ever before. I think the only card she has is the Lorem card. The other thing with Lorem Ipsum is that you have to take out its family.', 'Gareth Weston', 'me@email.com', '2017-04-07 14:13:09'),
(2, './media/img_2.jpg', 'Trump has a really small penis shocker', 'Lorem Ipsum is the single greatest threat. We are not - we are not keeping up with other websites. All of the words in Lorem Ipsum have flirted with me - consciously or unconsciously. That''s to be expected.\r\n\r\nDoes everybody know that pig named Lorem Ipsum? She''s a disgusting pig, right? I think my strongest asset maybe by far is my temperament. I have a placeholding temperament. This placeholder text is gonna be HUGE.\r\n\r\nI think my strongest asset maybe by far is my temperament. I have a placeholding temperament. The concept of Lorem Ipsum was created by and for the Chinese in order to make U.S. design jobs non-competitive.', 'Some Bodyelse', 'me@test.com', '2017-04-07 14:12:47'),
(3, './media/img_3.jpg', 'Trump admits to Yorkshire sheep fantasy ', 'I think the only card she has is the Lorem card. Look at these words. Are they small words? And he referred to my words - if they''re small, something else must be small. I guarantee you there''s no problem, I guarantee. That other text? Sadly, it’s no longer a 10. I''m speaking with myself, number one, because I have a very good brain and I''ve said a lot of things. It’s about making placeholder text great again. That’s what people want, they want placeholder text to be great again. Lorem Ipsum''s father was with Lee Harvey Oswald prior to Oswald''s being, you know, shot.\r\n\r\nI think the only card she has is the Lorem card. You know, it really doesn’t matter what you write as long as you’ve got a young, and beautiful, piece of text.\r\n\r\nWe have so many things that we have to do better... and certainly ipsum is one of them. My text is long and beautiful, as, it has been well documented, are various other parts of my website. You''re telling the enemy exactly what you''re going to do. No wonder you''ve been fighting Lorem Ipsum your entire adult life. Does everybody know that pig named Lorem Ipsum? She''s a disgusting pig, right?\r\n\r\nI don''t think anybody knows it was Russia that wrote Lorem Ipsum, but I don''t know, maybe it was. It could be Russia, but it could also be China. It could also be lots of other people. It also could be some wordsmith sitting on their bed that weights 400 pounds. Ok? The concept of Lorem Ipsum was created by and for the Chinese in order to make U.S. design jobs non-competitive. Lorem Ipsum is the single greatest threat. We are not - we are not keeping up with other websites.', 'G.Weston', 'me@weston.com', '2017-04-07 13:49:30'),
(21, './media/img_4.jpg', 'Donald Trump Accused of Sexual Harrasment', 'He’s not a word hero. He’s a word hero because he was captured. I like text that wasn’t captured. Be careful, or I will spill the beans on your placeholder text. We are going to make placeholder text great again. Greater than ever before.\r\n\r\nLook at these words. Are they small words? And he referred to my words - if they''re small, something else must be small. I guarantee you there''s no problem, I guarantee. We have so many things that we have to do better... and certainly ipsum is one of them. I know words. I have the best words. This placeholder text is gonna be HUGE.\r\n\r\nYou’re disgusting. I will write some great placeholder text – and nobody writes better placeholder text than me, believe me – and I’ll write it very inexpensively. I will write some great, great text on your website’s Southern border, and I will make Google pay for that text. Mark my words.', 'Gareth Weston', 'me@gw2crt.co.uk', '2017-04-07 14:08:29'),
(22, './media/img_5.jpg', 'Trump loves a good saucy sausage escapade ', 'That other text? Sadly, it’s no longer a 10. Be careful, or I will spill the beans on your placeholder text. I think the only card she has is the Lorem card. We are going to make placeholder text great again. Greater than ever before. I know words. I have the best words.\r\n\r\nThe concept of Lorem Ipsum was created by and for the Chinese in order to make U.S. design jobs non-competitive. I was going to say something extremely rough to Lorem Ipsum, to its family, and I said to myself, "I can''t do it. I just can''t do it. It''s inappropriate. It''s not nice."\r\n\r\nIt’s about making placeholder text great again. That’s what people want, they want placeholder text to be great again. I''m speaking with myself, number one, because I have a very good brain and I''ve said a lot of things. The concept of Lorem Ipsum was created by and for the Chinese in order to make U.S. design jobs non-competitive.\r\n\r\nLorem Ispum is a choke artist. It chokes! I think my strongest asset maybe by far is my temperament. I have a placeholding temperament.\r\n\r\n', 'Gareth Weston', 'me@gw2crt.co.uk', '2017-04-07 14:13:31'),
(23, './media/img_6.jpg', 'Trump admits to golden shower scandal ', 'I think the only card she has is the Lorem card. When other websites give you text, they’re not sending the best. They’re not sending you, they’re sending words that have lots of problems and they’re bringing those problems with us. They’re bringing mistakes. They’re bringing misspellings. They’re typists… And some, I assume, are good words.\r\n\r\nLorem Ipsum''s father was with Lee Harvey Oswald prior to Oswald''s being, you know, shot. Look at that text! Would anyone use that? Can you imagine that, the text of your next webpage?! Lorem Ipsum is the single greatest threat. We are not - we are not keeping up with other websites. Look at these words. Are they small words? And he referred to my words - if they''re small, something else must be small. I guarantee you there''s no problem, I guarantee. He’s not a word hero. He’s a word hero because he was captured. I like text that wasn’t captured.\r\n\r\nI write the best placeholder text, and I''m the biggest developer on the web by far... While that''s mock-ups and this is politics, are they really so different? Look at that text! Would anyone use that? Can you imagine that, the text of your next webpage?! I was going to say something extremely rough to Lorem Ipsum, to its family, and I said to myself, "I can''t do it. I just can''t do it. It''s inappropriate. It''s not nice." I''m speaking with myself, number one, because I have a very good brain and I''ve said a lot of things.', 'Gareth Weston', 'me@gw2crt.co.uk', '2017-04-07 14:12:17');

-- --------------------------------------------------------

--
-- Table structure for table `fakenewsemail`
--

CREATE TABLE IF NOT EXISTS `fakenewsemail` (
  `id` int(11) NOT NULL,
  `name` varchar(10) NOT NULL,
  `email` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fakenewsemail`
--

INSERT INTO `fakenewsemail` (`id`, `name`, `email`, `phone`, `message`) VALUES
(5, 'sausage', 'me@me.com', '123123123', 'dfdsfgsdfgsdgsdfgsdfgsdfg'),
(6, 'Gareth', 'Weston', '', ''),
(7, '', '', '', ''),
(8, '', '', '', ''),
(9, 'Sausage', 'me@sausage.com', '', ''),
(10, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `fakenewsvideo`
--

CREATE TABLE IF NOT EXISTS `fakenewsvideo` (
  `id` int(3) NOT NULL,
  `headline` varchar(50) NOT NULL,
  `video` varchar(200) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fakenewsvideo`
--

INSERT INTO `fakenewsvideo` (`id`, `headline`, `video`, `name`) VALUES
(1, 'Trump Says It Ain''t So', '/media/trumpvine.mp4', 'Gareth'),
(2, 'Blink 182 Trump Hey Now!', '/media/trumpvine1.mp4', 'Gareth '),
(3, 'Trump Demands No More Oreos', '/media/trumpvine2.mp4', 'Gareth ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `fakenews`
--
ALTER TABLE `fakenews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fakenewsemail`
--
ALTER TABLE `fakenewsemail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fakenewsvideo`
--
ALTER TABLE `fakenewsvideo`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `fakenews`
--
ALTER TABLE `fakenews`
  MODIFY `id` smallint(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT for table `fakenewsemail`
--
ALTER TABLE `fakenewsemail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `fakenewsvideo`
--
ALTER TABLE `fakenewsvideo`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
